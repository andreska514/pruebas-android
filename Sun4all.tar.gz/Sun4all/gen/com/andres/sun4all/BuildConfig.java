/** Automatically generated file. DO NOT MODIFY */
package com.andres.sun4all;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}